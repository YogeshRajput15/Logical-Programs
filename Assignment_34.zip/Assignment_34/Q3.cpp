//3.write a program to accept N values from user and return addition of that value.

#include<iostream>
using namespace std;

template<class T>
T AddN(T *crr,int iSize)
{
    
    int i=0;
    T Sum;

    for(i=0;i<iSize;i++)
    {
      T Sum=Sum+crr[i];
    }
    return Sum;
}
int main() 
{
    int arr[]={10,20,30,40,50};
    int iSum=AddN<int>(arr,5);
    cout<<"Addition is: "<<iSum<<endl;
    
   
    float brr[]={10.0,3.7,9.8,8.7};
    float fSum=AddN<float>(brr,4);
    cout<<"Addition is : "<<fSum<<endl; 

    
    return 0;
}