//3.Write a program which accept string from user and return  the difference between frequency of small characters and frequency of capital characters.
//Input: "MarvellouS"
//Output: 6  (8-2)

#include<iostream>
using namespace std;

int Difference(char *str)
{
    int iCap=0;
    int iSmall=0;
    int iDiff=0;

    while(*str!='\0')
    {
        if((*str<=95)&&(*str>=65))
        {
            iCap++;
         }
         else if((*str<=122)&&(*str>=97))
         {
            iSmall++;            
         }
        str++;
    }
    iDiff=iSmall-iCap;
    return iDiff;
}
int main()
{
    char arr[20];
    int iRet=0;

    printf("Enter string\n");
    scanf("%[^'\n]s",arr);

    iRet=Difference(arr);

    printf("Difference Between small characters and capital characters is : %d",iRet);

    return 0;
}