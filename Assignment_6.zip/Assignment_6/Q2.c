//write a program which accept number from user and return the count of odd digitd
//Input:    2395
//Output:   3
//Input:    -1018
//Output:   2

#include<stdio.h>

int CountOdd(int iNo)
{
    int iDigit=0;
    
    int iFrequency=0;
    
    if(iNo<0)
    {
        iNo=-iNo;
    }

    while(iNo>0)
    {
        iDigit=iNo%10;
        if(iNo%2!=0)
        {
            iFrequency++;
        }
        iNo=iNo/10;

    }
    return iFrequency;
}
int main()
{
    int iValue=0;
    int iRet=0;
    printf("Enter numbet\n");
    scanf("%d",&iValue);

    iRet=CountOdd(iValue);
    printf("count of odd digits :%d",iRet);

    return 0;
}