//Accept one character from user and check wheather that character is vowel (a,i,e,o,u) or not.
//Input:  E       Output: TRUE
//Input:d          Output:FALSE

#include<stdio.h>
#include<stdbool.h>

typedef int BOOL ;

#define TRUE    1
#define  FALSE  0

BOOL ChkVowel(char cWord)
{
    

    if(cWord=='a'||cWord=='i'||cWord =='e'||cWord=='o'||cWord=='u')
    {
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}
int main()
{
    char cValue='\0';
    BOOL bRet=FALSE;

    printf("Enter character\n");
    scanf("%c",&cValue);

    bRet=ChkVowel(cValue);
    if (bRet==TRUE)
    {
        printf("It is Vowel\n");
    }
    else
    {
        printf("It is not Vowel\n");
    }

    return 0;
}