//Accept one charecter form user and convert case of that character
//Input: a   output: A
//Input:D     output: d

#include<stdio.h>

void DisplayConvert(char cValue)
{
    if(cValue)

}
int main()
{
    char cValue='\0';
    printf("Enter Character\n");
    scanf("%c",&cValue);

    DisplayConvert(cValue);

    return 0;
}