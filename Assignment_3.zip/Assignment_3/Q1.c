//write a program which accept one number form user and print that number of even numbers on screen
// Input:   7
//output:   2   4   6   8   10  12  14  

#include<stdio.h>


void PrintEven(int iNo)
{
    int iCnt=0;

    if(iNo<=0)
    {
        iNo=-iNo;
    }
    {
        for(iCnt=1;iCnt<=(2*iNo);iCnt++)
        {
            if(iCnt%2==0)   
            {
                printf("%d\n",iCnt);
            } 
         }

    }
  
        
        }
         
        
    

 int main()
{
    int iValue=0;
   
    printf("Enter number\n");
   
    scanf("%d",&iValue);
   
    PrintEven(iValue);
   
    return 0;
}

 