//Draw stack layout of each program seperately
//3.write a recursive program which displays below pattern
//Input: 5
//output:5  4  3  2  1


#include<stdio.h>

void Display(int iNo)
{
      
    int iCnt = iNo;
    if(iCnt>0)
    {
        printf("%d\t",iCnt);
        iCnt--;
         Display(iCnt);
    }
}
int main()
{
   int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}