//Draw stack layout of each program seperately
//4.write a recursive program which displays below pattern
//Input: 6
//output:a  b  c  d  e  f


#include<stdio.h>

void Display(int iNo)
{
   static   char ch='a';
   static int cCnt = 0;
    if(cCnt<iNo)
    {
      printf("%c\t",ch);
      cCnt++;
      ch++;
       Display(iNo);
    }
}
int main()
{
   int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}