//Draw stack layout of each program seperately
//1.write a recursive program which displays below pattern
//Input: 5
//output: *   *  *  *  *


#include<stdio.h>

void Display(int iNo)
{
    static int iCnt=0;
    if(iCnt<iNo)
    {
        printf("*\t",iCnt);
        iCnt++;
         Display(iNo);
    }
}
int main()
{
    int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

    Display(iValue);

    return 0;
}