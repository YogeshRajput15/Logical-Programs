//write generic program to accept N values and search first occurence of any specific value.
//Input: 10  20  30  10  30  40  10  40  10
//value to search : 40
//Output: 6

#include<iostream>
using namespace std;

template<class T>
T SearchFirst(T *arr,int iSize,T iNo)
{
    int i=iSize,iCnt=1;
      while(arr[i]!=iNo)
      {
        iCnt++;
        iSize--;
        i--;
      }
      
    
   return iCnt;
}

int main()
{
    int arr[]={10,20,30,10,30,40,10,40,10};
    int iRet=SearchFirst(arr,9,40);
    cout<<iRet<<endl;

     float brr[]={10.60,20.68,30.22,10.32,30.42,40.52,10.82,40.52,10.33};
    float fRet=SearchFirst<float>(brr,9,30.22);
    cout<<fRet<<endl;

    return 0;
}