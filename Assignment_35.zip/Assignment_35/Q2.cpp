//2.write generic program to accept N values and count frequency of any specific value.
//Input:    10  20  30  10 30  40  10  40  10
//value to check frequency : 10
//Output:   4

#include<iostream>
using namespace std;

template<class T>
T Frequency(T *brr,int iSize, T iNo)
{
    int i=0,iCnt=0;
    for(i=0;i<iSize;i++)
    {
        
        if(iNo==brr[i])
        {
            iCnt++;
        }
        
    }
return iCnt;
}
int main()
{
    int arr[]={10,20,30,10,30,40,10,40,10};
    int iRet=Frequency(arr,9,10);
    cout<<"frequency is : "<<iRet<<endl;

float crr[]={10.50,20.0,30.60,10.50,20.0,40.21,10.50,20.0,10.50};
   float fRet=Frequency<float>(crr,9,20.0);
    cout<<"frequency is : "<<fRet<<endl;

    return 0;
}