//write generic program to accept N values and search last occurence of any specific value.
//Input: 10  20  30  10  30  40  10  40  10
//value to search : 40
//Output: 8

#include<iostream>
using namespace std;

template<class T>
T SearchLast(T *arr,int iSize,T iNo)
{
    int i=0,iCnt=1;
      while(arr[i]!=iNo)
      {
        iCnt++;
        i++;
        while(arr[i]!=iNo)
        {
            iCnt++;
            i++;
        }
      }
      
    
   return iCnt;
}

int main()
{
    int arr[]={10,20,30,10,30,40,10,40,10};
    int iRet=SearchLast(arr,9,40);
    cout<<iRet<<endl;

     float brr[]={10.60,20.68,30.22,10.32,30.22,40.52,10.82,40.52,10.33};
    float fRet=SearchLast<float>(brr,9,30.22);
    cout<<fRet<<endl;

    return 0;
}