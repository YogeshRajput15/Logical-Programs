//write a program which accept 2 string from user and concat second string after first string(Inplement strcat()function)

//Input:   "Marvellous Infosystems"
//            "Logic Building"

//Output:    "Marvellous Infosystems Logic Building"

#include<stdio.h>

void StrCatX(char *src,char *dest)
{
    while(*dest != '\0')
    {
        dest++;
    }
    while(*src != '\0')
    {
        *dest = *src;
        src++;
        dest++;
    }
    *dest = '\0';     
}

int main()
{
    char arr[30] = "Marvellous Infosystems";
    char brr[50] = "Logic Building";

    StrCatX( arr, brr);

    printf("%s",brr);

    return 0;
}}