//5. Accept N number from user and accept one another number as NO, return  index of last occurence of that No.
//Input: N:    6
//        NO:   66
//Elements:  85 66  3  66  93  88  
//Output:  3
//Input: N:    6
//      NO:    93
//Elements:  85 11  3   15  11  111
//Output:  -4

#include<stdio.h>
#include<stdlib.h>


int LastOcc(int Arr[],int iLength,int iNo)
{
    int iCnt=0,iFreq=0;
 for(iCnt=0;iCnt<iLength;iCnt++)
 {
 
    if(Arr[iCnt]!=iNo)
    {
        iFreq++;
    } 
    else if(Arr[iCnt]==iNo)
    {
        continue;
        break;
    }

 }
 iFreq--;
 return iFreq;
}

int main()
{
    int iSize=0,iCnt=0,iRet=0,iValue=0;
    int *p=NULL;


    printf("Enter Number of elements\n");
    scanf("%d",&iSize);

    printf("Enter the number\n");
    scanf("%d",&iValue);

    p=(int *)malloc(sizeof(int)*iSize);
    
    if(p==NULL)
    {
        printf("Unable to allocate memory");
        return -1;
    }

    printf("Enter the values :\n");
    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&p[iCnt]);
    }
  iRet=LastOcc(p,iSize,iValue);
   
  if(iRet==-1)
  {
    printf("There is no such number\n");
  }
  else
  {
    printf("Last occurence of number is %d",iRet);
  }
  
   
    free(p);

    
    return 0;
}