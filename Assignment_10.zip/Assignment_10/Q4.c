//5. Accept N number from user and accept range ,Display all elements from that range
//Input: N:    6
//       Start:   60
//         end:   90
//Elements:  85 66  3 76  93  88  
//Output:  66  76  88 
//Input: N:    6
//      NO:    30
//      end:    50
//Elements:  85 66  3   76  93  88
//Output:  

#include<stdio.h>
#include<stdlib.h>


void  Range(int Arr[],int iLength,int iStart,int iEnd)
{
    int iCnt=0,iFreq=0;
 for(iCnt=0;iCnt<iLength;iCnt++)
 {
    if(Arr[iCnt]==iStart)
    {
        printf("%d",*Arr);
    }
    else if (Arr[iCnt]==iEnd)
    {
        break;
    }

 }
}

int main()
{
    int iSize=0,iCnt=0,iValue1=0,iValue2=0;
    int *p=NULL;


    printf("Enter Number of elements\n");
    scanf("%d",&iSize);

    printf("Enter the number\n");
    scanf("%d",&iValue1);
    printf("Enter the number\n");
    scanf("%d",&iValue2);

    p=(int *)malloc(sizeof(int)*iSize);
    
    if(p==NULL)
    {
        printf("Unable to allocate memory");
        return -1;
    }

    printf("Enter the values :\n");
    for(iCnt=0;iCnt<iSize;iCnt++)
    {
        scanf("%d",&p[iCnt]);
    }
  Range(p,iSize,iValue1,iValue2);
   
  
   
    free(p);

    
    return 0;
}