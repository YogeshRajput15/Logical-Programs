//write a program which accept string from user and accept one character . return index of last occurence of that character.
//Input: "Marvellous Multi Os"
//            M
//Output: 11
//Input:  "Marvellous Multi Os"
//              w
//Output:  -1

#include<iostream>
using namespace std;

int LastChar(char *str, char ch)
{
    int iNo;
    int iCnt=0;
    for(iCnt='\0';iCnt<=*str;iCnt--)
    {
        if(*str==ch)
        {
            iNo++;
        }
        *str--;
    }
}
int main()
{
    char arr[20];
    char cValue;
    int iRet=0;

    print("Enter string\n");
    scanf("%[^'\n']s",arr);

    printf("Enter character\n");
    cin>>cValue;

    iRet=LastChar(arr,cValue);

    printf("Character location is %d",iRet);
    
    return 0;

}