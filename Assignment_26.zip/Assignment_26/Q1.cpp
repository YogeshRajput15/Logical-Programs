//1. write a program which accept string from user and accept one character,check wheather that character is present in string or not
//Input : "Marvellous Multi OS"
//            e
// Output: TRUE

// "Marvellous Multi OS"
//        W
//Output:  FALSE

#include<iostream>
using namespace std;
#define TRUE 1
#define FALSE 0

typedef int BOOL;

BOOL ChkChar(char *str, char ch)
{
    while(*str!='\0')
    {
        if(*str==ch)
        {
            return TRUE;
        }
        str++;
        

    }

}

int main()
{
    char arr[20];
    char cValue;
    BOOL bRet=FALSE;

    printf("Enter string\n");
    scanf("%[^'\n']s",arr);

    printf("Enter the character\n");
    cin>>cValue;

    bRet=ChkChar(arr,cValue);

    if(bRet==TRUE)
    {
        printf("Character found");
    }
    else
    {
        printf("Character not found");
    }

    return 0;

}