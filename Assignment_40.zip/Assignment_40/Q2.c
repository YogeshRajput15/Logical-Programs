//write application which accept file name from user and create that file in read mode.
//Input:   Demo.txt
//Output:  File opened successfully

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

int main()
{
    char Fname[20];
    int fd=0;

    printf("Enter File name\n");
    scanf("%s",Fname);

    fd=creat(Fname,0777);

    if(fd==-1)
    {
        printf("Unable to create file\n");
        return -1;
    }

    printf("File is create succesfully with fd :%d",fd);

    return 0;
}