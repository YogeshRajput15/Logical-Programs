//Write application which accept file name from user and one string from user.Write that string at the end of file.
//Input: Demo.txt
 //   Hello world
// Write Hello world at the end of Demo.txt file

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<string.h>

#define FILESIZE 1024

int main()
{
    char Fname[20];
    int fd=0;  //file descriptor
    char Data[100];
    int iRet=0;

    printf("Enter file name to open\n");
    scanf("%s",Fname);
    
    printf("Enter the data that you want to write \n");
    scanf(" %[^'\n']s",Data);

   fd = open(Fname,O_RDWR | O_APPEND);
    if(fd == -1)
    {
        printf("Unable to open the file\n");
        return -1;  
    }

    
    printf("File is succesfully created with FD %d\n",fd);

 iRet= write(fd,Data,strlen(Data));
    printf("%d byte succesfully written in the file\n",iRet);
    
    return 0;
}