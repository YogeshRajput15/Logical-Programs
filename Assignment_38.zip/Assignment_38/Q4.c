//Draw stack layout of each program seperately
//4.write a recursive program which accept string from user and return its factorial
//Input:    5
//output:  120


#include<stdio.h>

int Fact(int iNo)
{
  static int iMult=1;

   if(iNo>0)
   {
        iMult=iMult*iNo;
        iNo--;
        Fact(iNo);
   }
   return iMult;

   

    
}
int main()
{
   int iRet=0;
  int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

   iRet=Fact(iValue);
   printf("%d",iRet);

    return 0;
}