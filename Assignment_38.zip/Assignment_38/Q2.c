//Draw stack layout of each program seperately
//2.write a recursive program which accept number from user and return summation of its digit
//Input: 879
//output:   24


#include<stdio.h>

int Sum(int iNo)
{
    static int  iSum=0,iDigit=0;
    if(iNo>0)
    {
        iDigit=iNo%10;
        iSum=iSum+iDigit;
        iNo=iNo/10;
        Sum(iNo);
    }
    return iSum;

    
}
int main()
{
   int iValue=0,iRet=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

   iRet= Sum(iValue);
   printf("summation is :%d",iRet);

    return 0;
}