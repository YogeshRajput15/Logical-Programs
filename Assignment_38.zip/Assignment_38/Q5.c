//Draw stack layout of each program seperately
//5.write a recursive program which accept string from user and return the products of digits

//Input:    523
//output:  30


#include<stdio.h>

int Mult(int iNo)
{
  static int iMult=1,iDigit=1;

   if(iNo>0)
   {
        iDigit=iNo%10;
        iMult=iMult*iDigit;
        iNo=iNo/10;
        Mult(iNo);
   }
   return iMult;

   

    
}
int main()
{
   int iRet=0;
  int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

   iRet=Mult(iValue);
   printf("%d",iRet);

    return 0;
}