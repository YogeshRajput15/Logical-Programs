//write a program which accept number form user and display its multiplication of factors
//Input: 12
//Output: 144   (1*2*3*4*6)
//Input:13  
//Ouput:1   (1)
//Input:10
//Output:10 (1*2*5)


#include<stdio.h>
void DisplayMult(int iNo)
{
    int iMult=1;
    int iDigit=0;

     if(iNo<0)
    {
        iNo=-iNo;
    }
    
   for(iDigit=1;iDigit<iNo/2;iDigit++)
    { 
         if(iNo%iDigit==0)
        {
           iMult=iMult*iDigit; 
           {
               printf("%d",iMult);
           }
          }
        
        
       
    }
    
}

int main()
{
    
    int iValue=0;
    printf("Enter number\n");
    scanf("%d",&iValue);

    DisplayMult(iValue);
    return 0;
}