//5.Write a program which accept file name and one count from user and read that number of character from starting position
//Input: Demo.txt
//Output: Display first 12 character from Demo.txt




#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<io.h>

#define FILESIZE 1024

void DisplayN(char FName[],int iSize)
{
    int fd = 0;    
    char Data[FILESIZE];
    
   fd =open(FName,O_RDWR);
    if(fd == -1)
    {
        printf("Unable to open the file\n");
        return ;  
    }

  
    read(fd,Data,iSize);
    write(1,Data,iSize);

    close(fd);
 
}

int main()
{
    char FileName[30];
    int iValue=0;
    int iRet = 0;

    printf("Enter file name \n");
    scanf(" %[^'\n']s",FileName);

    printf("Enter the number of  character\n");
    scanf(" %d",&iValue);

    DisplayN(FileName,iValue);


    return 0;
}
