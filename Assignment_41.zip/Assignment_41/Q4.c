//write a program which accept file name from user and one character from user and count number of occurences of that character from that file 
//Input : Demo.txt      'M'
//Ouput:  Frequency of M is 7


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<io.h>

#define FILESIZE 1024

int CountChar(char FName[],char ch)
{
    int fd = 0;    
    int iRet = 0,i=0,iCnt=0;

    char Data[FILESIZE];
    
   fd =open(FName,O_RDWR);
    if(fd == -1)
    {
        printf("Unable to open the file\n");
        return -1;  
    }

    while((iRet = read(fd,Data,sizeof(Data))) != 0)
    {
        for(i=0;i<iRet;i++)
        {
            if(Data[i]==ch)
            {
                iCnt++;
            }
        }
        
    }

    close(fd);
    return iCnt;
}

int main()
{
    char FileName[20];
    char cValue='\0';
    int iRet = 0;

    printf("Enter file name to open\n");
    scanf("%s",FileName);

    printf("Enter the character\n");
    scanf(" %c",&cValue);

    iRet =CountChar(FileName,cValue);

    printf("Frequency is : %d\n",iRet);

    return 0;
}
