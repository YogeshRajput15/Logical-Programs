//write a program which accept file name from user and count number of white spaces from that file 
//Input : Demo.txt
//Ouput:  Number of white spaces are 13


#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>

#define FILESIZE 1024

int CountWhite(char FName[])
{
    int fd = 0;    
    int iRet = 0,i=0,iCnt=0;
    char Data[FILESIZE];   
    

    fd = open(FName,O_RDWR);
    if(fd == -1)
    {
        printf("Unable to open the file\n");
        return -1;  // Failure
    }

    while((iRet = read(fd,Data,sizeof(Data))) != 0)
    {
        for(i=0;i<iRet;i++)
        {
            if(Data[i]==' ')
            {
                iCnt++;
            }
        }
        
    }

    close(fd);
    return iCnt;
}

int main()
{
    char FileName[20];
    int iRet = 0;

    printf("Enter file name to open\n");
    scanf("%s",FileName);

    iRet =CountWhite(FileName);
    printf("Number of White Spaces : %d\n",iRet);

    return 0;
}
