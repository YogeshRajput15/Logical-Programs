//Draw stack layout of each program seperately
//4.write a recursive program which displays below pattern
//output: A     B       C       D       F

#include<stdio.h>

void Display()
{
    static char iCnt='A';
    if(iCnt<='F')
    {
        printf("%c\t",iCnt);
        iCnt++;
         Display();
    }
}
int main()
{
    Display();
    return 0;
}