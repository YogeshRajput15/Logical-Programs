//Draw stack layout of each program seperately
//1.write a recursive program which displays below pattern
//output: *   *   *   *   *

#include<stdio.h>

void Display()
{
    static int iCnt=1;
    if(iCnt<=5)
    {
        printf("*\t");
        iCnt++;
         Display();
    }
}
int main()
{
    Display();
    return 0;
}