//Draw stack layout of each program seperately
//5.write a recursive program which displays below pattern
//output: a  b  c  d  e  f
#include<stdio.h>

void Display()
{
    static char iCnt='a';
    if(iCnt<='f')
    {
        printf("%c\t",iCnt);
        iCnt++;
         Display();
    }
}
int main()
{
    Display();
    return 0;
}