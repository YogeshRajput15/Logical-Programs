//write a program which accept number from user and check wheather it contains 0 in it or not
//Input:    139
//Output:   there is no zero
//Input:    10158
//Output:   it contains zero
//Input:    9000
//Output:   It contains zero

#include<stdio.h>

typedef int BOOL;

#define TRUE 1
#define FALSE 0

BOOL ChkZero(int iNo)
{
    int iDigit=0;
    
 
    while(iNo>0)
    {
        iDigit=iNo%10;
        if(iDigit==0)
        {
           return TRUE;
           break;
        }
        iNo=iNo/10;

    }
    return iDigit;
}

int main()
{
    int iValue=0;
    BOOL bRet=0;
    printf("Enter the number\n");
    scanf("%d",&iValue);

    bRet=ChkZero(iValue);

    if(bRet==TRUE)
    {
        printf("It contains Zero\n");
    }
    else
    {
        printf("There is no zero\n");
    }




    return 0;
}