//write a program which accept string from user and count the number of white spaces
//Input:  "Marvellous"
//Output: 0
//Input: "Marvellous Infosystems"
//Output:  1
//Input: "Marvellous Infosystem by Piyush Manohar Khairnar"
//Output: 5

#include<iostream>
using namespace std;

int CoutWhite(char *str)
{
    int iCnt=0;
    while(*str!='\0')
    {
       if(*str==32)
       {
         iCnt++;
       }
        str++;
    }
    return iCnt;
   
}
int main()
{
    char arr[20];
    int iRet=0;

    printf("Enter String\n");
    scanf("%[^'\n']s",arr);

   iRet=CoutWhite(arr);

   printf("%d",iRet);

    return 0;
}