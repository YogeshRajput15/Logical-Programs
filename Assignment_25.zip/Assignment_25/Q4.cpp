//write a program which accept string from user and display only digit from that string
//Input:  "Marve89llous121"
//Output: 89121

#include<iostream>
using namespace std;

void DisplayDigit(char *str)
{
    int iDigit=0;
    while(*str!='\0')
    {
       if((*str>=48)&&(*str<=57))
       {
         iDigit=*str;
         printf("%c",iDigit);
       }
        str++;
    }
   
}
int main()
{
    char arr[20];

    printf("Enter String\n");
    scanf("%[^'\n']s",arr);

    DisplayDigit(arr);

    return 0;
}