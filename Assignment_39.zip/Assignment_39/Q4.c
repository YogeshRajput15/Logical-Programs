//Draw stack layout of each program seperately
//4.write a recursive program which accept number from user and return smallest digit

//Input:   87983
//output:  3


#include<stdio.h>

int Min(int iNo)
{
  static int iDigit=0,iMin=0;
  iMin=iNo%10;
  while(iNo!=0)
  {
    iDigit=iNo%10;
    if(iMin>iDigit)
    {
        iMin=iDigit;
    }
    iNo=iNo/10;
  }
  return iMin;
}
int main()
{
    int iValue=0,iRet=0;
  
    printf("Enter Number\n");
    scanf("%d",&iValue);

   iRet=Min(iValue);
   printf("Minimum digit is : %d",iRet);

    return 0;
}