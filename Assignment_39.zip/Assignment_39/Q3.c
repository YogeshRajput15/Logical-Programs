//Draw stack layout of each program seperately
//3.write a recursive program which accept number from user and count number of small characters 

//Input:   HEllWOrlD
//output:  5


#include<stdio.h>

int Small(char *str)
{
    static int iCnt=0;
   if(*str!='\0')
   {
     if((*str>='a')&&(*str<='z'))
     {
        iCnt++;
     }
     str++;
     Small(str);
   }
   return iCnt;
}
int main()
{
   char arr[20];
   int iRet=0;

  
    printf("Enter string\n");
    scanf("%[^'\n]s",arr);

   iRet=Small(arr);
   printf("small characters : %d",iRet);

    return 0;
}