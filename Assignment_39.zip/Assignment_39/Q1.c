//Draw stack layout of each program seperately
//1.write a recursive program which accept string from user and count white spaces

//Input:    HE llo WOr lD
//output:  3


#include<stdio.h>

int WhiteSpace(char *str)
{
    static int iCnt=0;
   if(*str!='\0')
   {
    if(*str==' ')
    {
        iCnt++;
    }
    str++;
    WhiteSpace(str);
   }
   return iCnt;

    
}
int main()
{
   int iRet=0;
  char arr[30];

    printf("Enter string\n");
    scanf("%[^'\n]s",arr);

   iRet=WhiteSpace(arr);
   printf("white spaces in string are : %d",iRet);

    return 0;
}