//All below question are depends on ASCII values of characters. Please consider below table to solve the questions
//1. Write a program which displays ASCII table . Table contain symbol,Decimal, Hexadecimal and Octal representation of every member from 0 to 255.

#include <stdio.h>  
void DisplayASCII()
{
  int asciTable;
    printf (" The complete ASCII table of the characters in the C ");  
    for (asciTable = 0; asciTable < 255; asciTable++)  
    {  
        printf (" \n The value of '%c' character is: %d", asciTable, asciTable);
         printf (" \n The value of '%d' Decimal is: %d", asciTable, asciTable);
          printf (" \n The value of '%o' Octal is: %d", asciTable, asciTable);
           printf (" \n The value of '%x' Hexadecimal is: %d", asciTable, asciTable);  
}
}

int main()  
{
  DisplayASCII();
  return 0;
} 
    