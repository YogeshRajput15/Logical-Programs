//Accept number from user and check wheather number is even or odd
#include<stdio.h>

#define TRUE 1
#define FALSE 0

typedef int BOOL;
BOOL ChkEven(int iNo)
{
    
    if((iNo%2)==0)
    {
        printf("The given value is even\n"); 
    }
    else
    {
        printf("The given value is Odd\n");

    }

}

int main()
{
 int iValue=0;
 BOOL bRet=FALSE;

 printf("Enter Number\n");
 scanf("%d",&iValue);

 bRet=ChkEven(iValue);

 return 0;   
}